g++ -c lab61.cpp
g++ -o lab61 lab61.o -lpthread -lrt
./lab61