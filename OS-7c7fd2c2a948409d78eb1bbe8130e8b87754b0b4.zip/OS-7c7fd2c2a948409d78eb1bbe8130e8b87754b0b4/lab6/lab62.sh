g++ -c lab62.cpp
g++ -o lab62 lab62.o -lpthread -lrt
./lab62