g++ -c lab32.cpp
g++ -o lab32 lab32.o -lpthread
./lab32