g++ -c lab33.cpp
g++ -o lab33 lab33.o -lpthread
./lab33