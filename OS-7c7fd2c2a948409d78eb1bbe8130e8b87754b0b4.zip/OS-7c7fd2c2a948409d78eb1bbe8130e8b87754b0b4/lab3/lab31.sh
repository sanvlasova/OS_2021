g++ -c lab31.cpp
g++ -o lab31 lab31.o -lpthread
./lab31