g++ -c lab21.cpp
g++ -o lab21 lab21.o -lpthread
./lab21