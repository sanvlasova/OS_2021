g++ -c lab22.cpp
g++ -o lab22 lab22.o -lpthread
./lab22