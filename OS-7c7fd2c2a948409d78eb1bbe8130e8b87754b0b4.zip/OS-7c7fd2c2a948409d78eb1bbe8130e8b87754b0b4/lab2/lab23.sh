g++ -c lab23.cpp
g++ -o lab23 lab23.o -lpthread
./lab23