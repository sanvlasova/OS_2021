g++ -c lab412.cpp
g++ -o lab412 lab412.o -lpthread
./lab412