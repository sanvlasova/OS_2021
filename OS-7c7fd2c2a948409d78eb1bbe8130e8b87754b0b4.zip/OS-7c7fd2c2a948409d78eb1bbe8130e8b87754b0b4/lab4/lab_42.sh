g++ -c lab422.cpp
g++ -o lab422 lab422.o -lpthread
./lab422