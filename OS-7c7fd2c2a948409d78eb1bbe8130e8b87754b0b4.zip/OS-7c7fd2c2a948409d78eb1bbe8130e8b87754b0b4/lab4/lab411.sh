g++ -c lab411.cpp
g++ -o lab411 lab411.o -lpthread
./lab411