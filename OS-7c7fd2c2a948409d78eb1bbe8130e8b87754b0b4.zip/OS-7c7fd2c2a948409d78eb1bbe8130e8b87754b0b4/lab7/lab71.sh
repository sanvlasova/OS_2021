g++ -c lab71.cpp
g++ -o lab71 lab71.o -lpthread
./lab71