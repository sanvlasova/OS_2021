g++ -c lab72.cpp
g++ -o lab72 lab72.o -lpthread
./lab72