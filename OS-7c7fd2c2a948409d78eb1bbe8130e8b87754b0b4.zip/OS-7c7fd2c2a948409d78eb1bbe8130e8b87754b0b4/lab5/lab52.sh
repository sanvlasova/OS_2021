g++ -c lab52.cpp
g++ -o lab52 lab52.o -lpthread
./lab52