g++ -c lab51.cpp
g++ -o lab51 lab51.o -lpthread
./lab51