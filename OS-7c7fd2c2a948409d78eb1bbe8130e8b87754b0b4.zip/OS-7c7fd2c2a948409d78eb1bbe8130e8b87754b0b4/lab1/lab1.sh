g++ -c lab1.cpp
g++ -o lab1 lab1.o -lpthread
./lab1