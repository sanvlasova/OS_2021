#!/bin/bash
g++	-c	lab2.cpp
g++	-o	lab2	lab2.o		-lpthread
g++	-c	lab2_2.cpp
g++	-o	lab2_2	lab2_2.o		-lpthread
g++	-c	lab2_3.cpp
g++	-o	lab2_3	lab2_3.o		-lpthread
