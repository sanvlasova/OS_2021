#!/bin/bash
g++	-c	lab1.cpp
g++	-o	lab1	lab1.o		-lpthread
g++	-c	lab2.cpp
g++	-o	lab2	lab2.o		-lpthread