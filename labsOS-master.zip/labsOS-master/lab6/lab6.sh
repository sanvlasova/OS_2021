#!/bin/bash
g++ -c lab6_1.cpp
g++ -o lab6_1 lab6_1.o -lpthread -lrt
g++ -c lab6_2.cpp
g++ -o lab6_2 lab6_2.o -lpthread -lrt