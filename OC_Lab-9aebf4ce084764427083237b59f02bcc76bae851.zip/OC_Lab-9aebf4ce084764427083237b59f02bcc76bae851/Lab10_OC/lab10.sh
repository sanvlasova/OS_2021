#!/bin/bash
g++ -o lab10 lab10.cpp
