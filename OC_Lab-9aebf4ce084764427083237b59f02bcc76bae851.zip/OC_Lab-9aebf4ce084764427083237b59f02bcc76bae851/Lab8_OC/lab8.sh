#!/bin/bash
g++ lab8_1.cpp -lpthread -o prog1 -lrt
g++ lab8_2.cpp -lpthread -o prog2 -lrt

