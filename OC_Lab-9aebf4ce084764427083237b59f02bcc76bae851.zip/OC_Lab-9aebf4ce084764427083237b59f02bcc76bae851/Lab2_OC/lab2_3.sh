#!/bin/bash

g++ -c lab2_3.cpp
g++ -o lab2_3 lab2_3.o -lpthread
