#!/bin/bash

g++ -c lab2_1.cpp
g++ -o lab2_1 lab2_1.o -lpthread
