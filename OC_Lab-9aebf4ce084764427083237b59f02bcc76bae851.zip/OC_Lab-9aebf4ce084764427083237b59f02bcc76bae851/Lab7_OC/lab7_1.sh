#!/bin/bash
g++ -c lab7_1.cpp
g++ -o lab7_1 lab7_1.o -lpthread

