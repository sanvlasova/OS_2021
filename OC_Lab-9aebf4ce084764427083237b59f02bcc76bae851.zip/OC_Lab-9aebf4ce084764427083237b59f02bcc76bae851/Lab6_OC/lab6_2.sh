#!/bin/bash

g++ -c lab6_2.cpp
g++ -o lab6_2 lab6_2.o -lpthread -lrt
