#!/bin/bash

g++ -c lab6_1.cpp
g++ -o lab6_1 lab6_1.o -lpthread -lrt
