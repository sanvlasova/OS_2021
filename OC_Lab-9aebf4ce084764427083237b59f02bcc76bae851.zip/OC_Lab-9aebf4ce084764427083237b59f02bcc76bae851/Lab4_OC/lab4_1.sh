#!/bin/bash

g++ lab4_1.cpp -o prog1
./prog1 1 2 3 4
rm prog1
