#!/bin/bash

g++ lab4_1.cpp -o prog1
g++ lab4_2.cpp -o prog2
./prog2 1 2 3
rm prog1 prog2
