#!/bin/bash

g++ -c lab5_1.cpp
g++ -o lab5_1 lab5_1.o -lpthread
