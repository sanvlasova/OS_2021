#!/bin/bash

g++ -c lab5_2.cpp
g++ -o lab5_2 lab5_2.o -lpthread
