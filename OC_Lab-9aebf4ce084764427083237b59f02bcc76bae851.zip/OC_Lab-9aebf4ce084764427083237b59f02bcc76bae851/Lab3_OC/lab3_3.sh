#!/bin/bash

g++ -c lab3_3.cpp
g++ -o lab3_3 lab3_3.o -lpthread
