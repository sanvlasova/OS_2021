#!/bin/bash

g++ -c lab3_2.cpp
g++ -o lab3_2 lab3_2.o -lpthread
