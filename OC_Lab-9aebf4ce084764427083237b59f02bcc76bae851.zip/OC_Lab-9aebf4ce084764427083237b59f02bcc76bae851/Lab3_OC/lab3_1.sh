#!/bin/bash

g++ -c lab3_1.cpp
g++ -o lab3_1 lab3_1.o -lpthread
