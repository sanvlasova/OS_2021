g++ lab2_1.cpp -lpthread
./a.out
rm a.out
