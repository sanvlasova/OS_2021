g++ lab2_2.cpp -lpthread
./a.out
rm a.out
