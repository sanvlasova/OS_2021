# LETI OS labs

Лабораторные работы выполнил Тюменцев А.С.

Группа 9894.

Преподаватель - Широков Владимир Владимирович

[Методические указания.pdf](https://github.com/SkyPwner/LETI-OS-labs/files/6266747/default.pdf)
