g++ lab3_3.cpp -lpthread
./a.out
rm a.out
