g++ lab3_2.cpp -lpthread
./a.out
rm a.out
