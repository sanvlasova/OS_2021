g++ lab3_1.cpp -lpthread
./a.out
rm a.out
