g++ Lab1.cpp -lpthread
./a.out
rm a.out
