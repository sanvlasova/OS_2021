g++ Lab1_newTask.cpp -lpthread
./a.out
rm a.out
